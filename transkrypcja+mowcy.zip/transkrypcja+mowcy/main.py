
import torch
from whisper import load_model
import torchaudio
import os
from pydub import AudioSegment
from pyannote.audio import Pipeline

# Inicjalizacja modelu Whisper
model = load_model("small") ## small - 15+ minut, medium - prawie 20 minut (dla 11 minutowego nagrania)

# Inicjalizacja PyAnnote
token = "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"
pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token=token)

def load_and_convert_audio(audio_path):
    """Funkcja wczytująca plik audio, konwertując go na WAV (16000 Hz, mono), jeśli jest to plik MP3"""
    file_extension = os.path.splitext(audio_path)[1].lower()

    if file_extension == '.mp3':
        wav_path = audio_path.replace('.mp3', '.wav')
        audio = AudioSegment.from_mp3(audio_path)
        audio = audio.set_frame_rate(16000)
        audio = audio.set_channels(1)
        audio.export(wav_path, format="wav")
        audio_path = wav_path

    signal, sample_rate = torchaudio.load(audio_path)
    if sample_rate != 16000:
        signal = torchaudio.transforms.Resample(orig_freq=sample_rate, new_freq=16000)(signal)
    return audio_path  # Zwracamy tylko ścieżkę do przetworzonego pliku WAV

def diarize_audio(audio_path):
    """Funkcja do diarizacji mówców"""
    diarization = pipeline(audio_path)
    speaker_segments = []
    for segment in diarization.itertracks(yield_label=True):
        start, end, speaker = segment[0].start, segment[0].end, segment[2]
        speaker_segments.append((start, end, speaker))
    return speaker_segments

def transcribe_audio(audio_path):
    """Funkcja do transkrypcji mowy na tekst"""
    transcription = model.transcribe(audio_path)
    return transcription

def combine_transcription_with_diarization(audio_path):
    """Łączenie transkrypcji z wynikami diarizacji"""
    diarization = diarize_audio(audio_path)
    transcription = transcribe_audio(audio_path)

    segments = []
    for segment in diarization:
        start, end, speaker = segment
        text = ""
        for word in transcription['segments']:
            if start <= word['start'] <= end:
                text += word['text'] + " "
        segments.append(f"{speaker}: {text.strip()}")
    return segments

def save_transcription_to_file(segments, output_path):
    """Zapis transkrypcji do pliku tekstowego"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for segment in segments:
            f.write(segment + "\n")

def save_plain_transcription(transcription, output_path):
    """Zapisuje zwykłą transkrypcję do pliku"""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(transcription['text'])

if __name__ == "__main__":
    audio_file = r"audio_files\test2.mp3"  # ścieżka do pliku audio
    plain_output_file = r"output\plain_transcription.txt"  # Ścieżka do pliku z prostą transkrypcją
    output_file = r"output\transcription2.txt"  # Ścieżka do pliku wynikowego

    try:
        audio_path = load_and_convert_audio(audio_file)
        transcription = transcribe_audio(audio_path)

        # Zapis zwykłej transkrypcji
        save_plain_transcription(transcription, plain_output_file)

        # Zapis transkrypcji z rozpoznawaniem mówców
        segments = combine_transcription_with_diarization(audio_path)
        save_transcription_to_file(segments, output_file)

        print(f"Prosta transkrypcja zapisana w {plain_output_file}")
        print(f"Transkrypcja z rozpoznawaniem mówców zapisana w {output_file}")
    except Exception as e:
        print(f"Błąd: {e}")
